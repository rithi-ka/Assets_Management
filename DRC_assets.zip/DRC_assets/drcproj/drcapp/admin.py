from django.contrib import admin
from .models import asserts



# Register your models here.

@admin.register(asserts)
class UserAdmin(admin.ModelAdmin):    
        # list_display = ('System_Number', 'User_Name', 'Department','Location', 'Floor_Number','Port_Number','file','OperatingSystem','Processor','Drives','LoggedUser','Controllers','BusAdapters','VirusProtection','Communications','SystemModel','MainCircuitBoard',
        
        # 'MemoryModules','Printers','Display','Multimedia','GroupPolicies','OtherDevices','HostedVirtualMachines','UploadedBY','Time')

#admin.site.register(User)
          list_display = ('System_Number', 'User_Name', 'Department','Location', 'Floor_Number','Port_Number','OperatingSystem','Processor','Drives','IPAddress','MacAddress','SystemModel','MainCircuitBoard',
        
        'MemoryModules','Display','UploadedBY','Time')