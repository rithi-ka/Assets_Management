# import re

# s1=['\n\n\r\n\t\t\t\t\t\tDrives\r\n\t\t\t\t\t\n\n\r\n\t\t\t\t\t\t\t492.27GigabytesUsableHardDriveCapacity267.78GigabytesHardDriveFreeSpaceNVMeBC711NVMeSKhynix512GB[Harddrive](512.11GB)--drive0,s/nFJABN43381210B620,SMARTStatus:Healthy\r\n\t\t\t\t\t\t\n\n\n']

# listToStr = ' '.join([str(elem) for elem in s1])
# print(listToStr)


# ree = re.sub(r'\s','',listToStr)

# # print(ree)

import 

for ip in range(1, 256):
  fullIP = '10.10.54' + ip
  if(Ping(fullIP) == True):
    print(fullIP + ' responded')
  else:
    print(fullIP + ' did not respond')