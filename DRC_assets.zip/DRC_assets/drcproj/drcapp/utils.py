# import re

# def extract_hardware_info(system_info: str):
    # system_model_match = re.findall(
    #     r'(?:LENOVO\s+\S+\s+Lenovo\s+[A-Za-z0-9\-]+|'
    #     r'Dell Inc\.\s+(?:Inspiron|Latitude)\s+\d{3,4}|'
    #     r'HP\s+HP\s+\d{3}\s+G\d\s+MT\s+Business\s+PC|'
    #     r'Acer\s+[A-Za-z0-9\-]+\s+Aspire\s+[A-Za-z0-9\-]+|'
    #     r'ASUSTeK COMPUTER INC\.\s+[A-Za-z0-9\-]+|'
    #     r'Micro\-Star International\s+[A-Za-z0-9\-]+)',
    #     system_info
    # )

#     main_circuit_board_match = re.findall(r'Board:\s*([A-Za-z0-9\s\-]+)', system_info)
#     memory_modules_match = re.findall(r'(\d+\s+Megabytes\s+Usable\s+Installed\s+Memory)', system_info)
#     controller_match = re.findall(r'(Intel\(R\).+?Controller)', system_info)
#     display_match = re.findall(r'(Intel\(R\).+?\[Display adapter\])', system_info)

#     return {
#         "SystemModel": system_model_match if system_model_match else "N/A",
#         "MainCircuitBoard": main_circuit_board_match[0] if main_circuit_board_match else "N/A",
#         "MemoryModules": memory_modules_match[0] if memory_modules_match else "N/A",
#         "Controllers": controller_match[0] if controller_match else "N/A",
#         "Display": display_match if display_match else [],
#     }
# Inside drcapp/utils.py
import re

def extract_system_model(system_info: str):
    match = re.search(
        r'(?:LENOVO\s+\S+\s+Lenovo\s+[A-Za-z0-9\-]+|'
        r'Dell Inc\.\s+(?:Inspiron|Latitude)\s+\d{3,4}|'
        r'HP\s+HP\s+\d{3}\s+G\d\s+MT\s+Business\s+PC|'
        r'Acer\s+[A-Za-z0-9\-]+\s+Aspire\s+[A-Za-z0-9\-]+|'
        r'ASUSTeK COMPUTER INC\.\s+[A-Za-z0-9\-]+|'
        r'Micro\-Star International\s+[A-Za-z0-9\-]+)',
        system_info
    )
    return match.group(0) if match else "Unknown"
