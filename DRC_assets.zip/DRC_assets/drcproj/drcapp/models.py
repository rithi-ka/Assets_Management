from enum import unique
from django.db import models

# Create your models here.
class asserts(models.Model):
    ##  Left Side Div 
    System_Number = models.CharField(max_length=45,default='',null= True)
    User_Name = models.CharField(max_length=70,default='',null=True)
    Department = models.CharField(max_length=100,default='',null =True)
    Location = models.CharField(max_length=100, default='',null=True)
    Floor_Number = models.CharField(max_length=100, default='',null=True)
    Port_Number = models.CharField(max_length=100,default='',null=True)
    # file = models.FileField(blank='True', null='True', upload_to='media/', default='')
    OperatingSystem = models.CharField(max_length=10000, blank='True', null='True', default='')
    Processor  = models.CharField(max_length=10000, blank='True', null='True', default='')
    Drives = models.CharField(max_length=65000, blank='True', null='True', default='')
    # LoggedUser = models.CharField(max_length=10000, blank='True', null='True', default='')
    # Controllers = models.CharField(max_length=10000, blank='True', null='True', default='')
    # BusAdapters = models.CharField(max_length=10000, blank='True', null='True', default='')
    # VirusProtection = models.CharField(max_length=10000, blank='True', null='True', default='')
    IPAddress = models.CharField(max_length=10000, blank='True', null='True', default='')
    MacAddress = models.CharField(max_length=10000, blank='True', null='True', default='')
    
    ## 

    # right Side Div 

    SystemModel = models.CharField(max_length=100,default='')
    MainCircuitBoard = models.CharField(max_length=100,default='', null=True)
    MemoryModules = models.CharField(max_length=100,default='', null=True)
    # Printers = models.CharField(max_length=10000,default='', null=True)
    Display = models.CharField(max_length=100,default='', null=True)
    # Multimedia = models.CharField(max_length=10000,default='', null=True)
    # GroupPolicies = models.CharField(max_length=10000,default='', null=True)
    # OtherDevices = models.CharField(max_length=10000,default='', null=True)
    # HostedVirtualMachines = models.CharField(max_length=10000,default='', null=True)
    UploadedBY = models.CharField(max_length=100,default='',null=True)
    Time = models.CharField(max_length=40, default='', null=True)


def __str__(self):
        return self.System_Number