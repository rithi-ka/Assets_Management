
import sys
# from .models import HardwareInfo
# from .utils import extract_hardware_info
from drcapp .utils import extract_system_model 
# from PyQt5.QtWidgets import QApplication, QDialog, QMainWindow, QMessageBox, QPushButton
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.http import HttpResponse
from bs4 import BeautifulSoup
from .models import asserts
from django.contrib.auth.models import User, auth
from django.contrib import messages
from django.contrib.auth import logout,login 
from django.db.models import Q
import datetime
# import js2py
from django.urls import reverse_lazy
from django.views.generic.edit import DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin
import re
import unittest
from .models import asserts
import json


def show_system_info(request):
    systems = asserts.objects.all()  # Fetch all records
    return render(request, 'system_info.html', {'systems': systems})

class TestSystemModelExtraction(unittest.TestCase):
    def test_dell(self):
        self.assertEqual(extract_system_model("Dell Inc. Inspiron 15 3000"), "Dell Inc. Inspiron 15 3000")

    def test_hp(self):
        self.assertEqual(extract_system_model("HP 290 G4 MT Business PC"), "HP 290 G4 MT Business PC")

    def test_lenovo(self):
        self.assertEqual(extract_system_model("Lenovo ThinkPad X1 Carbon"), "Lenovo ThinkPad X1")

    def test_unknown(self):
        self.assertEqual(extract_system_model("Just a random string"), "Unknown")

if __name__ == "__main__":
    unittest.main()


def extract_system_model(text):
    pattern = re.compile(
        r"""(?ix)
        (?:
            Dell(?: Inc\.)?\s+(Inspiron\s+\d{2,4}\s+\d{4}|Latitude\s+\d{4}) |
            HP(?: Inc\.)?\s+(?:HP\s+)?\d{3,4}\s+G\d\s+MT\s+Business\s+PC |
            Lenovo\s+(ThinkPad|IdeaPad|Legion)\s+\S+ |
            Acer\s+(Aspire|Predator|Nitro)\s+\S+ |
            Asus\s+(ROG|VivoBook|ZenBook)\s+\S+ |
            MSI\s+(Modern|Stealth|GF|GE|GL)\s+\S+ |
            Apple\s+(MacBook\s+(Air|Pro))\s+\S+ |
            Toshiba\s+Satellite\s+\S+ |
            Samsung\s+(Notebook|Galaxy\s+Book)\s+\S+
        )
        """
    )
    match = pattern.search(text)
    return match.group(0) if match else "Unknown"


@login_required(login_url='login_user')
def Searchbox(request):

    if 'q' in request.GET:
        q = request.GET['q']
        data = asserts.objects.filter(System_Number__icontains=q)
        multiple_q = (
            Q(System_Number__icontains=q)|
            Q(User_Name__icontains=q)| 
            Q(Department__icontains=q)|
            Q(Location__icontains=q)|
            Q(Floor_Number__icontains=q)|
            Q(Port_Number__icontains=q)| 
            Q(OperatingSystem__icontains=q)| 
            Q(Processor__icontains=q)|
            Q(Drives__icontains=q)| 
            Q(Controllers__icontains=q)| 
            Q(SystemModel__icontains=q)| 
            Q(Communications__icontains=q)|
            Q(MainCircuitBoard__icontains=q)| 
            Q(Display__icontains=q))
        # # return render(request, 'result.html')

        # data = asserts.objects.annotate(search=SearchVector('System_Number','User_Name'),).filter(search=q)
        data = asserts.objects.filter(multiple_q)
    else:
        
        data = asserts.objects.all()
    context = {
             'key': data
    }
    
    return render(request,'search.html', context)




def logout_user(request):
    if User.is_authenticated:
   
        logout(request)
        return redirect('/')


def login_user(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('UploadBelarc')
        else:
            messages.info(request, 'Invalid Username or Password')
            return redirect('login_user')



    else:
        return render(request, 'login.html')
@login_required(login_url='login_user')
def query(request):
    
    # query = SELECT System_Number FROM webapplication_asserts;

    li = []

    # result = asserts.objects.raw( 'SELECT System_Number FROM webapplication_asserts PK id AS System_Number')
    # result = asserts.objects.raw( 'SELECT * FROM webapplication_asserts')
    r = asserts.objects.values('System_Number')
    # print(r)
    # [print(r[2])]
   
    for i in r:

        for j in i.values():
            print(j)

            li.append(j)
    print(li)

    #    li.append(i)
    # print(li[0].values)
    if 'APSPDCL1001' in li:
        print('yes')
    else:
        print('no')

    # # ree = {'key2': r }
    # # for i in ree.key2:

            
    

    return render(request, 'query.html')

def javascript(request):
    return render(request, 'javascript.html')



def checking(request):
    return render(request, 'checking.html' )


@login_required(login_url='login_user')
def UploadBelarc(request):
    if request.method != 'POST':
        return render(request, 'addandshow.html')

    uploaded_file = request.FILES.get('file')
    if not uploaded_file:
        messages.error(request, "No file uploaded.")
        return render(request, 'addandshow.html')

    file_name_parts = str(uploaded_file).split('_')
    if len(file_name_parts) < 6:
        messages.error(request, "Invalid file name format.")
        return render(request, 'addandshow.html')

    system_number = file_name_parts[0]
    if asserts.objects.filter(System_Number=system_number).exists():
        messages.info(request, "File for this system already exists.")
        return render(request, 'addandshow.html')

    soup = BeautifulSoup(uploaded_file, 'html.parser')
    left_sections = soup.find_all("div", class_="reportSection rsLeft")
    right_sections = soup.find_all("div", class_="reportSection rsRight")

    # -------- Extraction Logic Starts -------- #
    def extract_text(sections, index):
        try:
            return sections[index].text.strip()
        except IndexError:
            return ""

    # Operating System
    try:
        os_match = re.search(r'Windows \d+ [A-Z]+', extract_text(left_sections, 0))
        operating_system = os_match.group() if os_match else "Unknown"
    except Exception:
        operating_system = "Unknown"

    # Processor
    try:
        processor_text = extract_text(left_sections, 1)
        processor_match = re.search(r'\d+\.\d+ GHz.+?\d+-\d+', processor_text)
        processor = processor_match.group() if processor_match else "Unknown"
    except Exception:
        processor = "Unknown"

        # Memory Modules (RAM Details)
    try:
        mem_text = extract_text(right_sections, 2)
        slots = re.findall(r"Slot\s+(\w+):\s+(.*?)\s+(\d+\s?GB)", mem_text)
        memory_modules = "; ".join([f"{slot} - {desc} - {size}" for slot, desc, size in slots]) if slots else "No RAM slot details found"
    except Exception as e:
        print(f"Error extracting memory modules: {e}")
        memory_modules = "Unknown"


    # IP & MAC Addresses
    try:
        network_text = extract_text(left_sections, 7)
        ip_address = re.findall(r"\b(?:10\.|172\.|192\.)[0-9.]+\b", network_text)
        mac_address = re.findall(r"([\dA-F]{2}(?:[-:][\dA-F]{2}){5})", network_text)
    except Exception:
        ip_address, mac_address = [], []

                # Extract Memory Modules section
        mem_section = soup.find('b', string=re.compile(r'Memory Modules'))
        memory_modules = "No RAM slot details found"

        if mem_section:
            # Get the parent <td> and then the next <td> sibling with actual info
            mem_td = mem_section.find_parent('td')
            if mem_td and mem_td.find_next_sibling('td'):
                mem_text = mem_td.find_next_sibling('td').get_text(separator='\n', strip=True)

                # Print to debug what's inside (optional)
                print("---- Memory Modules Section ----")
                print(mem_text)
                print("---------------------------------")

                # Flexible regex to catch slot and size
                slots = re.findall(r"(Slot\s+\S+):\s+([\w\s\-]+)?\s*(\d+\s?GB)", mem_text)
                
                if slots:
                    memory_modules = "; ".join([
                        f"{slot.strip()} - {desc.strip()} - {size.strip()}" 
                        for slot, desc, size in slots
                    ])
                else:
                    # Provide raw fallback content
                    memory_modules = f"No RAM slot details matched pattern.\nExtracted content:\n{mem_text}"
            else:
                memory_modules = "Memory section found, but no details in sibling <td>."

        else:
            memory_modules = "No 'Memory Modules' section found in the HTML."

        # Clean up
        os.remove(file_path)

        context['memory_modules'] = memory_modules

    # System Model
    try:
        system_text = extract_text(right_sections, 0)
        system_model_match = re.search(
            r'(LENOVO\s+\S+|Dell Inc\.\s+\S+|HP\s+HP\s+\S+|Acer\s+\S+|ASUSTeK COMPUTER INC\.\s+\S+|Micro-Star International\s+\S+)',
            system_text, re.IGNORECASE)
        system_model = system_model_match.group() if system_model_match else "Unknown"
    except Exception:
        system_model = "Unknown"

    # Drives
    try:
        drives_text = extract_text(left_sections, 2)
        drives_match = re.search(r"(Drives.*?)\s+Memory Modules", drives_text, re.DOTALL)
        drives_cleaned = drives_match.group(1).strip() if drives_match else drives_text
    except Exception:
        drives_cleaned = "Unknown"
         

        #  # Memory Modules (RAM Details)
        # try:
        #     mem_text = extract_text(right_sections, 2)

        # # Only extract if it's a Windows OS
        #     if 'Windows' in operating_system:
        # # Example pattern: Slot A: 8GB DDR4 2400 MHz
        #         slots = re.findall(r"Slot\s+(\w+):\s+(.*?)(\d+\s?GB)", mem_text)
        #         memory_modules = "; ".join([f"{slot} - {desc.strip()} {size}" for slot, desc, size in slots]) if slots else "No RAM slot details found"
        #     else:
        #         memory_modules = "Non-Windows system: Memory not extracted"
        # except Exception:
        #     memory_modules = "Unknown"


    # Main Circuit Board
    try:
        mcb_text = extract_text(right_sections, 1)
        mcb_match = re.search(r"(Main Circuit Board.*?)\s+Memory", mcb_text, re.DOTALL)
        main_circuit_board = mcb_match.group(1).strip() if mcb_match else mcb_text
    except Exception:
        main_circuit_board = "Unknown"

    # # Memory Modules (RAM Details)
    # try:
    #     mem_text = extract_text(right_sections, 2)
    #     slots = re.findall(r"Slot\s+(\w+):\s+(.*?)\s+(\d+\s?GB)", mem_text)
    #     memory_modules = "; ".join([f"{slot} - {desc} - {size}" for slot, desc, size in slots]) if slots else "No RAM slot details found"
    # except Exception:
    #     memory_modules = "Unknown"



    # Display
    try:
        display_text = extract_text(right_sections, 4)
        display_match = re.search(r"(Display.*?)\s+Multimedia", display_text, re.DOTALL)
        display_cleaned = display_match.group(1).strip() if display_match else display_text
    except Exception:
        display_cleaned = "Unknown"

    # -------- Save to DB -------- #
    new_asset = asserts(
        System_Number=system_number,
        User_Name=file_name_parts[1],
        Department=file_name_parts[2],
        Location=file_name_parts[3],
        Floor_Number=file_name_parts[4],
        Port_Number=file_name_parts[5],
        OperatingSystem=operating_system,
        Processor=processor,
        Drives=drives_cleaned,
        IPAddress=ip_address,
        MacAddress=mac_address,
        SystemModel=system_model,
        MainCircuitBoard=main_circuit_board,
        MemoryModules=memory_modules,
        Display=display_cleaned,
        UploadedBY=request.user,
        Time=datetime.datetime.now()
    )
    new_asset.save()

    messages.success(request, "File uploaded and saved successfully.")
    return render(request, 'addandshow.html')
