from django.urls import path, include
# from drcapp import views
from django.contrib.auth.decorators import login_required
# from . import views


urlpatterns = [
      # path('admin/', admin.site.urls),
    # path('drcapp', include('drcapp.urls')),
      path('',include('drcapp.urls')),
    
]
